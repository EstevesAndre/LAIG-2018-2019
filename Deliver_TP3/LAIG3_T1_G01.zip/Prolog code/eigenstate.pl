:- consult('display.pl').
:- consult('gameloop.pl').
:- consult('menus.pl').
:- consult('utility.pl').
:- consult('game_over.pl').
:- consult('player_turn.pl').
:- consult('computer_turn.pl').
:- consult('data.pl').
:- consult('evaluation.pl').

eigenstate :- 
    play.